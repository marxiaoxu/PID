#include "fuzzy.h"
double fuzzy_pid(double Ma, double e, double e1, double  N, double  a, double  b, double  k2, double  ku, double  as, double  ao)
{
	 double y = 0,ed=0,E=0,E1=0,EC=0,EC1=0,a1=0,y1=0,y2=0;
ed = e - e1;
E = -(2 * N) * (e * k2 - (a + b)) / (b - a);
E1 = E;
EC = -(2 * N) * (ed - (a + b)) / (b - a);
EC1 = 270 * EC;
a1 = (1.0 / N) * (as - ao) * fabs(E1) + ao;
y1 = (-(a1 * E1 + (1 - a1) * EC1) / 2);
y2 = y1 * ku;
y = y2 * Ma;
return y;
}
