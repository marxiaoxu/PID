#include "math.h"
double fuzzy_pid(double Ma, double e, double e1, double  N, double  a, double  b, double  k2, double  ku, double  as, double  ao);

