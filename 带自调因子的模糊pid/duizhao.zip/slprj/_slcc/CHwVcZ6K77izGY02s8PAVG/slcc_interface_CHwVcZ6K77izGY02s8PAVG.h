#include "customcode_CHwVcZ6K77izGY02s8PAVG.h"
#ifdef __cplusplus
extern "C" {
#endif


/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
DLL_EXPORT_CC extern const char_T *get_dll_checksum_CHwVcZ6K77izGY02s8PAVG(void);
DLL_EXPORT_CC extern real_T fuzzy_pid_CHwVcZ6K77izGY02s8PAVG(real_T Ma, real_T e, real_T e1, real_T N, real_T a, real_T b, real_T k2, real_T ku, real_T as, real_T ao);

/* Function Definitions */
DLL_EXPORT_CC const uint8_T *get_checksum_source_info(int32_T *size);
#ifdef __cplusplus
}
#endif

